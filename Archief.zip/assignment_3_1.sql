-- SQLite
SELECT cars.brand, cars.model, cars.tax
FROM registered_cars AS cars
ORDER BY cars.tax DESC