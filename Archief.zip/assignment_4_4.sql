SELECT COUNT(cars.price) as amount
FROM registered_cars as cars
WHERE cars.price > 1000000